# V14 Slash Command Handler
Proje discord.js v14 üzerine yazılmıştır. **Gerekli olan minimum nodejs versiyonu v16.9** Örnek kullanım src/commands/ping.js dosyasında verilmiştir. Herhangi bir sorunla karşılaşırsanız [destek sunucuma](https://discord.gg/u6CcYxDchB) gelebilirsiniz!
 Destek olmak isterseniz projeye star verebilirsiniz.
 
![image](https://user-images.githubusercontent.com/63320170/175336722-373eaf92-1454-4bce-b97c-e8a629c2628e.png)

### Not: config.js dosyasında ayarlamalarinizi yapmayi unutmayin.
