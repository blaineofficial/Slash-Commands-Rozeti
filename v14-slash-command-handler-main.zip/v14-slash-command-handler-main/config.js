module.exports = {
  "prefix": "/",
  "owner": "690639157013381220",
  "token": "Bot Tokeniniz"
}
